#include "esp_camera.h"
#include <WiFi.h>
#include "esp_http_server.h"
#include <PubSubClient.h>

/* ================= WIFI ================= */
const char* ssid = "ESP32_CAM";
const char* password = "Cam@12345678";

/* ================= MQTT ================= */
const char* mqtt_server = "broker.hivemq.com";
const int   mqtt_port   = 1883;
const char* mqtt_topic  = "esp32cam/pir";

WiFiClient espClient;
PubSubClient mqttClient(espClient);

/* ================= PIR ================= */
#define PIR_PIN 13
#define BUZZER_PIN 12
#define FP 4
volatile int pirState = 0;

/* ================= CAMERA (AI THINKER) ================= */
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

httpd_handle_t camera_httpd = NULL;

/* ================= PIR TASK ================= */
void PIR_Task(void *pvParameters) {
  pinMode(PIR_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(FP, OUTPUT);
  while (true) {
    pirState = digitalRead(PIR_PIN);
    vTaskDelay(200 / portTICK_PERIOD_MS);
  }
}

/* ================= MQTT CONNECT ================= */
/* ================= MQTT TASK ================= */
void MQTT_Task(void *pvParameters) {
  int lastPirState = -1;
  mqttClient.setServer(mqtt_server, mqtt_port);

  while (true) {
    if (pirState != lastPirState) {
      lastPirState = pirState;
      char payload[4];
      snprintf(payload, sizeof(payload), "%d", pirState);
      Serial.print("MQTT PIR Sent: ");
      Serial.println(payload);
      if(pirState == 0)
      {
        Serial.println("Human");
        digitalWrite(BUZZER_PIN, HIGH);
        digitalWrite(FP, HIGH);
        delay(100);
      }
      else
      {
        Serial.println("NO Human");
        digitalWrite(BUZZER_PIN, LOW);
        digitalWrite(FP, LOW);
        delay(100);
      }
      Serial.println(payload);
    }

    vTaskDelay(300 / portTICK_PERIOD_MS);
  }
}

/* ================= STREAM HANDLER ================= */
esp_err_t stream_handler(httpd_req_t *req) {
  camera_fb_t *fb;
  char part_buf[64];

  httpd_resp_set_type(req, "multipart/x-mixed-replace;boundary=frame");
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");

  while (true) {
    fb = esp_camera_fb_get();
    if (!fb) return ESP_FAIL;

    size_t hlen = snprintf(part_buf, sizeof(part_buf),
      "--frame\r\nContent-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n",
      fb->len);

    httpd_resp_send_chunk(req, part_buf, hlen);
    httpd_resp_send_chunk(req, (const char *)fb->buf, fb->len);
    httpd_resp_send_chunk(req, "\r\n", 2);

    esp_camera_fb_return(fb);
    vTaskDelay(30 / portTICK_PERIOD_MS);
  }
}

/* ================= START HTTP SERVER ================= */
void startCameraServer() {
  httpd_config_t config = HTTPD_DEFAULT_CONFIG();
  config.server_port = 80;

  httpd_start(&camera_httpd, &config);

  httpd_uri_t stream_uri = {
    .uri = "/stream",
    .method = HTTP_GET,
    .handler = stream_handler,
    .user_ctx = NULL
  };

  httpd_register_uri_handler(camera_httpd, &stream_uri);

  Serial.println("HTTP server started");
}

/* ================= SETUP ================= */
void setup() {
  Serial.begin(115200);

  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer   = LEDC_TIMER_0;
  config.pin_d0       = Y2_GPIO_NUM;
  config.pin_d1       = Y3_GPIO_NUM;
  config.pin_d2       = Y4_GPIO_NUM;
  config.pin_d3       = Y5_GPIO_NUM;
  config.pin_d4       = Y6_GPIO_NUM;
  config.pin_d5       = Y7_GPIO_NUM;
  config.pin_d6       = Y8_GPIO_NUM;
  config.pin_d7       = Y9_GPIO_NUM;
  config.pin_xclk     = XCLK_GPIO_NUM;
  config.pin_pclk     = PCLK_GPIO_NUM;
  config.pin_vsync    = VSYNC_GPIO_NUM;
  config.pin_href     = HREF_GPIO_NUM;
  config.pin_sscb_sda = SIOD_GPIO_NUM;
  config.pin_sscb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn     = PWDN_GPIO_NUM;
  config.pin_reset    = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;

  // ⚠️ Recommended for stability
  config.frame_size   = FRAMESIZE_QVGA;
  config.jpeg_quality = 12;
  config.fb_count     = 1;

  if (esp_camera_init(&config) != ESP_OK) {
    Serial.println("Camera init failed");
    ESP.restart();
  }

  WiFi.begin(ssid, password);
  Serial.print("Connecting WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\n==========================");
  Serial.print("Stream : http://");
  Serial.print(WiFi.localIP());
  Serial.println("/stream");
  Serial.println("PIR    : MQTT ONLY");
  Serial.println("==========================");

  xTaskCreatePinnedToCore(PIR_Task,  "PIR Task",  2048, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(MQTT_Task, "MQTT Task", 4096, NULL, 1, NULL, 1);

  startCameraServer();
}

/* ================= LOOP ================= */
void loop() {
  vTaskDelay(portMAX_DELAY);
}
