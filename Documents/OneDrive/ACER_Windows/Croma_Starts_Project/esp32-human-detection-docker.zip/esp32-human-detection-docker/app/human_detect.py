import cv2
from ultralytics import YOLO
import requests
import time

model = YOLO("yolov8n.pt")

STREAM_URL = "http://192.168.29.180:81/stream"
cap = cv2.VideoCapture(STREAM_URL, cv2.CAP_FFMPEG)

if not cap.isOpened():
    print("❌ Cannot open stream")
    exit()

last_sent = 0

while True:
    ret, frame = cap.read()
    if not ret:
        continue

    results = model(frame, conf=0.5)
    human_found = False

    for r in results:
        for box in r.boxes:
            if int(box.cls[0]) == 0:
                human_found = True

    if human_found and time.time() - last_sent > 5:
        try:
            requests.get(
                "http://host.docker.internal:5000/detect",
                timeout=1
            )
            last_sent = time.time()
            print("🚨 Human detected")
        except:
            print("⚠ Flask not reachable")

cap.release()
