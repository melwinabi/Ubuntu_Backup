from flask import Flask, jsonify, send_from_directory
import os

# Flask app
app = Flask(
    __name__,
    static_folder="../web",
    static_url_path=""
)

# Shared detection flag
human_detected = False


# Serve main dashboard page
@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


# API called by YOLO process
@app.route("/detect")
def detect():
    global human_detected
    human_detected = True
    return "OK", 200


# API polled by frontend JavaScript
@app.route("/status")
def status():
    global human_detected
    state = human_detected
    human_detected = False
    return jsonify({"human": state})


# Optional: serve other static files explicitly
@app.route("/<path:filename>")
def static_files(filename):
    return send_from_directory(app.static_folder, filename)


if __name__ == "__main__":
    # IMPORTANT for Docker + Windows
    app.run(
        host="0.0.0.0",   # listen on all interfaces
        port=5000,        # exposed via Docker
        debug=False       # keep False for Docker
    )
