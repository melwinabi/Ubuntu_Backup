document.addEventListener("DOMContentLoaded", () => {

  /* =========================
     CONFIG
  ========================== */
  const PIR_API = "http://192.168.29.180/pir";
  const CHECK_INTERVAL = 1000;

  /* =========================
     ELEMENT
  ========================== */
  const detectStatus = document.getElementById("detectStatus");

  /* =========================
     PIR CHECK
  ========================== */
  async function checkPIR() {
    try {
      const response = await fetch(PIR_API, {
        method: "GET",
        cache: "no-store"
      });

      if (!response.ok) {
        throw new Error("HTTP error");
      }

      const data = await response.json();

      // ✅ VALID ONLINE STATES
      if (data.pir === 1) {
        detectStatus.textContent = "⚠ HUMAN DETECTED";
        detectStatus.className = "detected";
        return;
      }

      if (data.pir === 0) {
        detectStatus.textContent = "No Human Detected";
        detectStatus.className = "safe";
        return;
      }

      // ❌ INVALID DATA → OFFLINE
      throw new Error("Invalid PIR value");

    } catch (error) {
      detectStatus.textContent = "⚠ ESP32 OFFLINE";
      detectStatus.className = "detected";
    }
  }

  /* =========================
     START POLLING
  ========================== */
  setInterval(checkPIR, CHECK_INTERVAL);

});
