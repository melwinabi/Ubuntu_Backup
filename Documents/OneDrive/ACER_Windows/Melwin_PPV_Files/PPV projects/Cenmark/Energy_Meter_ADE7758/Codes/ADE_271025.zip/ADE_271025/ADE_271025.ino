#include <BluetoothSerial.h>
#include <SPI.h>
#include <ADE7758_AT.h>

#define ADE_IRQ_PIN 4

ADE7758 EnergyMeter;

// Measurement variables
float Volt_R, Volt_Y, Volt_B;
float Curr_R, Curr_Y, Curr_B;
float Watt_R, Watt_Y, Watt_B;
float VAR_R,  VAR_Y,  VAR_B;
float VA_R,   VA_Y,   VA_B;
float PF_R,   PF_Y,   PF_B;
float Freq = 0.0f;
uint8_t PhaseSequence = 0; // 0 = R-Y-B, 1 = R-B-Y (see note)

// Totals
float Tot_W = 0.0f, Tot_VAR = 0.0f, Tot_VA = 0.0f;
float Tot_kW = 0.0f, Tot_kVAR = 0.0f, Tot_kVA = 0.0f;
float PF_total = 0.0f;

// --- Calibration Constants ---
float V_SCALE    = 4682.0f;
float I_SCALE    = 142600.0f;
float WATT_SCALE = 0.0155f;
float VA_SCALE   = 0.37f;
float VAR_SCALE  = 0.05f;

void setup() {
  Serial.begin(115200);

  if (EnergyMeter.Init()) {
    Serial.println("ADE7758 Initialized");
  } else {
    Serial.println("ADE7758 Init FAILED!");
  }

  Calibrate_ADE7758();
}

void loop() {
  Read_ADE7758();

  Serial.println(F("=== ADE7758 Readings ==="));

  print3(F("Voltage (V):     "), Volt_R, Volt_Y, Volt_B, 2);
  print3(F("Current (A):     "), Curr_R, Curr_Y, Curr_B, 2);

  print3(F("Active  (W):     "), Watt_R, Watt_Y, Watt_B, 2);
  print3(F("Reactive(VAR):   "), VAR_R,  VAR_Y,  VAR_B,  2);
  print3(F("Apparent(VA):    "), VA_R,   VA_Y,   VA_B,   2);

  print3(F("Power Factor:    "), PF_R, PF_Y, PF_B, 3);

  Serial.print(F("Frequency:       ")); Serial.print(Freq, 2); Serial.println(F(" Hz"));
  Serial.print(F("Phase Sequence:  "));
  Serial.println( (PhaseSequence == 0) ? F("R-Y-B") : F("R-B-Y") );

  Serial.println(F("--- Totals ---"));
  Serial.print (F("Total Active Power:   ")); Serial.print(Tot_kW,   3); Serial.println(F(" kW"));
  Serial.print (F("Total Reactive Power: ")); Serial.print(Tot_kVAR, 3); Serial.println(F(" kVAR"));
  Serial.print (F("Total Apparent Power: ")); Serial.print(Tot_kVA,  3); Serial.println(F(" kVA"));
  Serial.print (F("Overall PF:           ")); Serial.println(PF_total, 3);

  Serial.println(F("-----------------------------"));
  Serial.println();
  delay(2000);
}

void print3(const __FlashStringHelper* label, float a, float b, float c, uint8_t digits) {
  Serial.print(label);
  Serial.print(F("R=")); Serial.print(a, digits);
  Serial.print(F("\tY=")); Serial.print(b, digits);
  Serial.print(F("\tB=")); Serial.println(c, digits);
}

void print1(const __FlashStringHelper* label, float v, const __FlashStringHelper* unit, uint8_t digits) {
  Serial.print(label); Serial.print(v, digits); if (unit) { Serial.print(F(" ")); Serial.print(unit); }
  Serial.println();
}
// ---------------- ADE7758 CONFIG ----------------
void Calibrate_ADE7758() {
  // NOTE: 0x04 sets DISCF=1 (CF disabled). Measurements still work; CF pins off.
  // If you ever want CF pins, use setOpMode(0x00).
  EnergyMeter.setOpMode(0x04);

  EnergyMeter.gainSetup(INTEGRATOR_OFF, FULLSCALESELECT_0_5V, GAIN_1, GAIN_4);

  // Dividers for line-cycle accumulation math (keep as you had)
  EnergyMeter.setupDivs(0x800, 0x800, 0x800);

  // Enable line-cycle accumulation on W/VAR/VA + ZX on all phases
  EnergyMeter.setLcycMode(0x0F);    // LWATT|LVAR|LVA + ZXSEL_A
  EnergyMeter.setLineCyc(20);

  // Interrupt mask (optional use)
  EnergyMeter.setMaskInterrupts(ZXTOA | ZXTOB | ZXTOC | LENERGY | ZXA | ZXB | ZXC);

  // COMPMODE: Keep your previous (ABS on APCF, Phase-A to CF). Not needed for per-phase reads.
  EnergyMeter.setCompMode(0x24);

  // Offsets (your values)
  EnergyMeter.setAVoltageOffset(-210);
  EnergyMeter.setACurrentOffset(-26);
  EnergyMeter.setAWattOffset(-10);
}

// ---------------- READ ADE7758 ----------------
static inline float clampPF(float x){
  if (x > 1.0f)  return 1.0f;
  if (x < -1.0f) return -1.0f;
  return x;
}

void Read_ADE7758() {
  // Read STATUS once (latched conditions)
  uint32_t status = EnergyMeter.getStatus();

  // --- Phase R (A) ---
  uint32_t rawVR = EnergyMeter.getAVRMS();
  uint32_t rawIR = EnergyMeter.getAIRMS();
  float    wR    = EnergyMeter.getWatt(PHASE_A);
  float    qR    = EnergyMeter.getVar(PHASE_A);
  float    sR    = EnergyMeter.getVa(PHASE_A);

  // --- Phase Y (B) ---
  uint32_t rawVY = EnergyMeter.getBVRMS();
  uint32_t rawIY = EnergyMeter.getBIRMS();
  float    wY    = EnergyMeter.getWatt(PHASE_B);
  float    qY    = EnergyMeter.getVar(PHASE_B);
  float    sY    = EnergyMeter.getVa(PHASE_B);

  // --- Phase B (C) ---
  uint32_t rawVB = EnergyMeter.getCVRMS();
  uint32_t rawIB = EnergyMeter.getCIRMS();
  float    wB    = EnergyMeter.getWatt(PHASE_C);
  float    qB    = EnergyMeter.getVar(PHASE_C);
  float    sB    = EnergyMeter.getVa(PHASE_C);

  // Frequency (your original scaling)
  Freq = EnergyMeter.getFreq() / 16.0f;

  // Phase sequence:
  // Use SEQERR (bit 19) from STATUS you defined in the header (0x080000).
  // If SEQERR is set, ADE7758 detected wrong ordering of zero-crossings.
  // We'll map SEQERR=0 => R-Y-B, SEQERR=1 => R-B-Y for display.
  PhaseSequence = (status & SEQERR) ? 1 : 0;

  // --- Apply scaling ---
  Volt_R = rawVR / V_SCALE;
  Volt_Y = rawVY / V_SCALE;
  Volt_B = rawVB / V_SCALE;

  Curr_R = rawIR / I_SCALE;
  Curr_Y = rawIY / I_SCALE;
  Curr_B = rawIB / I_SCALE;

  Watt_R = wR * WATT_SCALE;
  Watt_Y = wY * WATT_SCALE;
  Watt_B = wB * WATT_SCALE;

  VAR_R  = qR * VAR_SCALE;
  VAR_Y  = qY * VAR_SCALE;
  VAR_B  = qB * VAR_SCALE;

  VA_R   = sR * VA_SCALE;
  VA_Y   = sY * VA_SCALE;
  VA_B   = sB * VA_SCALE;

  // Per-phase PF (guard against divide-by-zero)
  PF_R = (VA_R != 0.0f) ? clampPF(Watt_R / VA_R) : 0.0f;
  PF_Y = (VA_Y != 0.0f) ? clampPF(Watt_Y / VA_Y) : 0.0f;
  PF_B = (VA_B != 0.0f) ? clampPF(Watt_B / VA_B) : 0.0f;

  // Totals
  Tot_W   = Watt_R + Watt_Y + Watt_B;     // W
  Tot_VAR = VAR_R  + VAR_Y  + VAR_B;      // VAR
  Tot_VA  = VA_R   + VA_Y   + VA_B;       // VA

  Tot_kW   = Tot_W   / 1000.0f;
  Tot_kVAR = Tot_VAR / 1000.0f;
  Tot_kVA  = Tot_VA  / 1000.0f;

  PF_total = (Tot_VA != 0.0f) ? clampPF(Tot_W / Tot_VA) : 0.0f;
}
