#ifndef BASE_H
#define BASE_H

#include <stdint.h>

/* Helper macro */
#define REG32(addr) (*(volatile uint32_t *)(addr))

/* RCC Base */
#define RCC_BASE        (0x58024400UL)

/* GPIO Base */
#define GPIOA_BASE      (0x58020000UL)
#define GPIOB_BASE      (0x58020400UL)
#define GPIOC_BASE      (0x58020800UL)
#define GPIOD_BASE      (0x58020C00UL)
#define GPIOE_BASE      (0x58021000UL)

/* USART Base */
#define USART1_BASE     (0x40011000UL)   // APB2
#define USART2_BASE     (0x40004400UL)   // APB1L
#define USART3_BASE     (0x40004800UL)   // APB1L

/* RCC Registers */
#define RCC_CR          (*(volatile uint32_t *)(RCC_BASE + 0x000))
#define RCC_CFGR        (*(volatile uint32_t *)(RCC_BASE + 0x010))
#define RCC_AHB4ENR     (*(volatile uint32_t *)(RCC_BASE + 0x0E0))
#define RCC_APB1LENR    (*(volatile uint32_t *)(RCC_BASE + 0x0E8))
#define RCC_APB2ENR     (*(volatile uint32_t *)(RCC_BASE + 0x0F0))

/* USART clock enable bits */
#define RCC_APB2ENR_USART1EN   (1U << 4)
#define RCC_APB1LENR_USART2EN  (1U << 17)
#define RCC_APB1LENR_USART3EN  (1U << 18)

/* GPIO structure */
typedef struct {
    volatile uint32_t MODER;
    volatile uint32_t OTYPER;
    volatile uint32_t OSPEEDR;
    volatile uint32_t PUPDR;
    volatile uint32_t IDR;
    volatile uint32_t ODR;
    volatile uint32_t BSRR;
    volatile uint32_t LCKR;
    volatile uint32_t AFRL;
    volatile uint32_t AFRH;
    volatile uint32_t BRR;
    volatile uint32_t ASCR;
} GPIO_TypeDef;

/* USART structure */
typedef struct {
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t CR3;
    volatile uint32_t BRR;
    volatile uint32_t GTPR;
    volatile uint32_t RTOR;
    volatile uint32_t RQR;
    volatile uint32_t ISR;
    volatile uint32_t ICR;
    volatile uint32_t RDR;
    volatile uint32_t TDR;
} USART_TypeDef;

/* GPIO Instances */
#define GPIOA   ((GPIO_TypeDef *) GPIOA_BASE)
#define GPIOB   ((GPIO_TypeDef *) GPIOB_BASE)
#define GPIOC   ((GPIO_TypeDef *) GPIOC_BASE)
#define GPIOD   ((GPIO_TypeDef *) GPIOD_BASE)
#define GPIOE   ((GPIO_TypeDef *) GPIOE_BASE)

/* USART Instances */
#define USART1  ((USART_TypeDef *) USART1_BASE)
#define USART2  ((USART_TypeDef *) USART2_BASE)
#define USART3  ((USART_TypeDef *) USART3_BASE)

#endif /* BASE_H */
