#ifndef GPIO_H
#define GPIO_H

#include "base.h"
#include <stdint.h>

/* Function prototypes */
void gpio_enable_clock(char port);
void gpio_pin_output(GPIO_TypeDef *port, uint8_t pin);
void gpio_pin_toggle(GPIO_TypeDef *port, uint8_t pin);

#endif /* GPIO_H */
