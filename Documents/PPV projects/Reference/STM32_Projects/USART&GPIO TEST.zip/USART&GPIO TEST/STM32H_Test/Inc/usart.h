#ifndef USART_H
#define USART_H

#include "base.h"

#define MAX_BUFFER 100

/* Function prototypes */
void Usart_Clock_init(void);
void USART1_Init(uint32_t baud, uint32_t pclk2);
void USART2_Init(uint32_t baud, uint32_t pclk1);
void USART3_Init(uint32_t baud, uint32_t pclk1);

void usart_write_char(USART_TypeDef *USARTx, char c);
void usart_write_string(USART_TypeDef *USARTx, const char *str);

char usart3_read_char(void);
int  usart3_available(void);
void usart3_read_string(char *buffer, int max_len);

#endif /* USART_H */
