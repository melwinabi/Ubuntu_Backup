#include "gpio.h"

/* Enable clock for GPIO port (A..E) */
void gpio_enable_clock(char port) {
    switch (port) {
        case 'A': RCC_AHB4ENR |= (1U << 0); break;
        case 'B': RCC_AHB4ENR |= (1U << 1); break;
        case 'C': RCC_AHB4ENR |= (1U << 2); break;
        case 'D': RCC_AHB4ENR |= (1U << 3); break;
        case 'E': RCC_AHB4ENR |= (1U << 4); break;
        default: break;
    }
}

/* Configure pin as general-purpose output (push-pull, default speed/pull) */
void gpio_pin_output(GPIO_TypeDef *port, uint8_t pin) {
    /* Reset mode bits then set to '01' (general purpose output) */
    port->MODER &= ~(3U << (pin * 2));
    port->MODER |=  (1U << (pin * 2));
}

/* Toggle pin (reads/modify ODR) */
void gpio_pin_toggle(GPIO_TypeDef *port, uint8_t pin) {
    port->ODR ^= (1U << pin);
}
