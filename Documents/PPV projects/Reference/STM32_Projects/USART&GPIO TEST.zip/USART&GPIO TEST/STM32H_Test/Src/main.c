#include "gpio.h"
#include "usart.h"

void delay(volatile uint32_t count) {
    while(count--) __asm__("nop");
}

int main(void) {
    /* Enable USART peripheral clocks */
    Usart_Clock_init();

    /* Initialize USARTs -- pass your actual peripheral clock (PCLK) values */
    USART1_Init(115200, 64000000);  /* example: PCLK2 = 64 MHz */
    USART2_Init(115200, 64000000);  /* example: PCLK1 = 64 MHz */
    USART3_Init(115200, 64000000);  /* example: PCLK1 = 64 MHz */

    /* Enable GPIO clocks for LEDs used (example ports B, D, E) */
    gpio_enable_clock('B');
    gpio_enable_clock('D');
    gpio_enable_clock('E');

    /* Configure pins as outputs (use pins that match your Nucleo board LEDs) */
    gpio_pin_output(GPIOB, 0);   /* LD1 */
    gpio_pin_output(GPIOE, 1);   /* LD2 */
    gpio_pin_output(GPIOB, 14);  /* LD3 */
    usart3_write_string("USART3 Ready. Type something:\r\n");


    char buffer[64];
    int idx = 0;

    while (1)
    {
        gpio_pin_toggle(GPIOB, 0);
        delay(2500000);
        gpio_pin_toggle(GPIOE, 1);
        delay(2500000);
        gpio_pin_toggle(GPIOB, 14);
        delay(2500000);
        if (usart3_available())
        {
        	usart3_write_string("available ");
        	usart3_write_string("\r\n");
            char c = usart3_read_char();

            if (c == '\r') {
                // ignore carriage return
            }
            else if (c == '\n') {
                buffer[idx] = '\0';   // null terminate

                usart3_write_string("You typed: ");
                usart3_write_string(buffer);
                usart3_write_string("\r\n");

                idx = 0;  // reset for next line
            }
            else {
                if (idx < (sizeof(buffer) - 1)) {
                    buffer[idx++] = c;
                }
                usart_write_char(USART3, c); // echo back
            }
        }
        usart3_write_string("OK<>\r\n");
    }


    return 0;
}
