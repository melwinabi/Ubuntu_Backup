#include "usart.h"

/* -------- Clocks -------- */
void Usart_Clock_init(void)
{
    /* Enable peripheral clocks for USART1/2/3 */
    RCC_APB2ENR |= RCC_APB2ENR_USART1EN;
    RCC_APB1LENR |= RCC_APB1LENR_USART2EN;
    RCC_APB1LENR |= RCC_APB1LENR_USART3EN;
}

/* -------- USART1: PA9 (TX), PA10 (RX) AF7 -------- */
void USART1_Init(uint32_t baud, uint32_t pclk2)
{
    /* GPIOA clock */
    RCC_AHB4ENR |= (1U << 0);  /* GPIOAEN */

    /* Alternate function mode for PA9/PA10 => MODER = 10 */
    GPIOA->MODER &= ~((3U << (9*2)) | (3U << (10*2)));
    GPIOA->MODER |=  ((2U << (9*2)) | (2U << (10*2)));   /* AF */

    /* AF7 for PA9/PA10 (AFRH indexes pins 8..15) */
    GPIOA->AFRH &= ~((0xFU << ((9U-8U)*4U)) | (0xFU << ((10U-8U)*4U)));
    GPIOA->AFRH |=  ((7U   << ((9U-8U)*4U)) | (7U    << ((10U-8U)*4U)));

    /* Baud rate (simple integer division; for accurate BRR use fractional calc) */
    USART1->BRR = (uint32_t)(pclk2 / baud);

    /* Enable UE, RE, TE (keep configuration minimal) */
    USART1->CR1 |= (1U << 0)  /* UE  */
                 | (1U << 2)  /* RE  */
                 | (1U << 3); /* TE  */
}

/* -------- USART2: PA2 (TX), PA3 (RX) AF7 -------- */
void USART2_Init(uint32_t baud, uint32_t pclk1)
{
    /* GPIOA clock */
    RCC_AHB4ENR |= (1U << 0);  /* GPIOAEN */

    /* Alternate function mode for PA2/PA3 */
    GPIOA->MODER &= ~((3U << (2*2)) | (3U << (3*2)));
    GPIOA->MODER |=  ((2U << (2*2)) | (2U << (3*2)));    /* AF */

    /* AF7 for PA2/PA3 (AFRL indexes pins 0..7) */
    GPIOA->AFRL &= ~((0xFU << (2U*4U)) | (0xFU << (3U*4U)));
    GPIOA->AFRL |=  ((7U   << (2U*4U)) | (7U    << (3U*4U)));

    USART2->BRR = (uint32_t)(pclk1 / baud);

    USART2->CR1 |= (1U << 0)  /* UE  */
                 | (1U << 2)  /* RE  */
                 | (1U << 3); /* TE  */
}

/* -------- USART3: PD8 (TX), PD9 (RX) AF7 -------- */
void USART3_Init(uint32_t baud, uint32_t pclk1)
{
    /* GPIOD clock */
    RCC_AHB4ENR |= (1U << 3);  /* GPIODEN */

    /* Alternate function mode for PD8/PD9 */
    GPIOD->MODER &= ~((3U << (8*2)) | (3U << (9*2)));
    GPIOD->MODER |=  ((2U << (8*2)) | (2U << (9*2)));    /* AF */

    /* AF7 for PD8/PD9 (AFRH indexes pins 8..15) */
    GPIOD->AFRH &= ~((0xFU << ((8U-8U)*4U)) | (0xFU << ((9U-8U)*4U)));
    GPIOD->AFRH |=  ((7U   << ((8U-8U)*4U)) | (7U    << ((9U-8U)*4U)));

    USART3->BRR = (uint32_t)(pclk1 / baud);

    USART3->CR1 |= (1U << 0)  /* UE  */
                 | (1U << 2)  /* RE  */
                 | (1U << 3); /* TE  */
}

/* -------- Generic TX helpers -------- */
void usart_write_char(USART_TypeDef *USARTx, char c)
{
    /* Wait TXE (bit 7) set: TX data register empty */
    while (!(USARTx->ISR & (1U << 7))) { /* wait */ }
    USARTx->TDR = (uint8_t)c;
}

void usart_write_string(USART_TypeDef *USARTx, const char *str)
{
    while (*str) {
        usart_write_char(USARTx, *str++);
    }
}

/* -------- USART3 convenience wrappers + RX helpers -------- */
char usart3_read_char(void) {
    /* Wait until RXNE (bit 5) = 1 (data received) on USART3 */
    while (!(USART3->ISR & (1U << 5))) { /* wait */ }
    return (char)(USART3->RDR & 0xFF);
}

int usart3_available(void)
{
    return (USART3->ISR & (1U << 5)) ? 1 : 0; // RXNE
}


void usart3_read_string(char *buffer, int max_len)
{
    int i = 0;
    if (max_len <= 0) return;
    while (i < (max_len - 1)) {
        /* wait for a byte */
        while (!(USART3->ISR & (1U << 5))) { /* wait */ }
        char c = (char)(USART3->RDR & 0xFF);
        if (c == '\r' || c == '\n') break;
        buffer[i++] = c;
    }
    buffer[i] = '\0';
}

/* Optional: dedicated USART3 TX wrapper */
void usart3_write_string(const char *str)
{
    usart_write_string(USART3, str);
}
