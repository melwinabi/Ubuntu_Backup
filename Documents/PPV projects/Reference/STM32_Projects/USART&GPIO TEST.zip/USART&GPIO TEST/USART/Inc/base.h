#ifndef BASE_H
#define BASE_H

#include <stdint.h>

/* Helper macro to access 32-bit registers */
#define REG32(addr) (*(volatile uint32_t *)(addr))

/* RCC Base */
#define RCC_BASE        (0x58024400UL)

/* GPIO Base Addresses */
#define GPIOA_BASE      (0x58020000UL)
#define GPIOB_BASE      (0x58020400UL)
#define GPIOC_BASE      (0x58020800UL)
#define GPIOD_BASE      (0x58020C00UL)
#define GPIOE_BASE      (0x58021000UL)

/*     USART          */
#define USART1          (0x40011000UL)
#define USART2          (0x40004400UL)
#define USART3          (0x40004800UL)

/* GPIO Register Offsets */
#define MODER_OFFSET    (0x00UL)
#define OTYPER_OFFSET   (0x04UL)
#define OSPEEDR_OFFSET  (0x08UL)
#define PUPDR_OFFSET    (0x0CUL)
#define IDR_OFFSET      (0x10UL)
#define ODR_OFFSET      (0x14UL)
#define BSRR_OFFSET     (0x18UL)

/* USART Register Offsets */

#endif
