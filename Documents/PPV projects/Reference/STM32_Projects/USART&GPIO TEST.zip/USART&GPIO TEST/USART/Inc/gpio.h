#ifndef GPIO_H
#define GPIO_H

#include "base.h"

/* GPIO structure */
typedef struct {
    uint32_t MODER;      // 0x00
    uint32_t OTYPER;     // 0x04
    uint32_t OSPEEDR;    // 0x08
    uint32_t PUPDR;      // 0x0C
    uint32_t IDR;        // 0x10
    uint32_t ODR;        // 0x14
    uint32_t BSRR;       // 0x18
    uint32_t LCKR;       // 0x1C
    uint32_t AFRL;       // 0x20
    uint32_t AFRH;       // 0x24
    uint32_t BRR;        // 0x28
    uint32_t ASCR;       // 0x2C
} GPIO_TypeDef;

/* RCC structure */
typedef struct {
    volatile uint32_t CR;         // 0x00
    volatile uint32_t HSICFGR;    // 0x04
    volatile uint32_t CRRCR;      // 0x08
    volatile uint32_t CFGR;       // 0x0C
    uint32_t RESERVED0[8];        // 0x10 - 0x2F
    volatile uint32_t PLLCKSELR;  // 0x30
    volatile uint32_t PLLCFGR;    // 0x34
    uint32_t RESERVED1[40];       // skip to 0xD8
    volatile uint32_t AHB1ENR;    // 0xD8
    volatile uint32_t AHB2ENR;    // 0xDC
    volatile uint32_t AHB4ENR;    // 0xE0
    volatile uint32_t APB1LENR;   // 0xE8
    volatile uint32_t APB2ENR;    // 0xEC
} RCC_TypeDef;

/* RCC Instances */
#define RCC      ((RCC_TypeDef *) RCC_BASE)

/* GPIO Instances */
#define GPIOA   ((GPIO_TypeDef *) GPIOA_BASE)
#define GPIOB   ((GPIO_TypeDef *) GPIOB_BASE)
#define GPIOC   ((GPIO_TypeDef *) GPIOC_BASE)
#define GPIOD   ((GPIO_TypeDef *) GPIOD_BASE)
#define GPIOE   ((GPIO_TypeDef *) GPIOE_BASE)

/* Function prototypes */
void gpio_enable_clock(char port);
void gpio_pin_output(GPIO_TypeDef *port, uint8_t pin);
void gpio_pin_toggle(GPIO_TypeDef *port, uint8_t pin);

#endif
