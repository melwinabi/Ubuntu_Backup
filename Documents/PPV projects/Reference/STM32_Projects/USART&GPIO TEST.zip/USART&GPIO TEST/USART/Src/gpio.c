#include "gpio.h"

/* Enable clock for GPIO port */
void gpio_enable_clock(char port) {
    switch(port) {
        case 'A': REG32(RCC_AHB4ENR) |= (1U << 0); break;
        case 'B': REG32(RCC_AHB4ENR) |= (1U << 1); break;
        case 'C': REG32(RCC_AHB4ENR) |= (1U << 2); break;
        case 'D': REG32(RCC_AHB4ENR) |= (1U << 3); break;
        case 'E': REG32(RCC_AHB4ENR) |= (1U << 4); break;
    }
}

/* Configure pin as output */
void gpio_pin_output(GPIO_TypeDef *port, uint8_t pin) {
    port->MODER &= ~(3U << (pin * 2));  // clear
    port->MODER |=  (1U << (pin * 2));  // set output mode
}

/* Toggle pin */
void gpio_pin_toggle(GPIO_TypeDef *port, uint8_t pin) {
    port->ODR ^= (1U << pin);
}
