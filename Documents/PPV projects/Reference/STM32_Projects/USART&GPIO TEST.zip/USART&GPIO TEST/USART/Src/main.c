#include "gpio.h"

static void delay(volatile uint32_t count) {
    while(count--) __asm__("nop");
}

int main(void) {
    /* Enable clock for GPIOB */
    gpio_enable_clock('B');
    gpio_enable_clock('E');
    /* Configure PB0 as output (LD1 on Nucleo-H7A3ZI-Q) */
    gpio_pin_output(GPIOB, 0);
    gpio_pin_output(GPIOE, 1);   // LD2
    gpio_pin_output(GPIOB, 14);  // LD3

    while (1)
    {
        gpio_pin_toggle(GPIOB, 0);   // Toggle LD1
        gpio_pin_toggle(GPIOE, 1);   // Toggle LD2
        gpio_pin_toggle(GPIOB, 14);  // Toggle LD3
        delay(5000000);
    }
}
