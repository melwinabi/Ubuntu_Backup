Src/main.o: ../Src/main.c ../Inc/base.h ../Inc/usart.h
../Inc/base.h:
../Inc/usart.h:
