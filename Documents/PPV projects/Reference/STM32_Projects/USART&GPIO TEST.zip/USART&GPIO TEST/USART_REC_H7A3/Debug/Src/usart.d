Src/usart.o: ../Src/usart.c ../Inc/base.h ../Inc/usart.h
../Inc/base.h:
../Inc/usart.h:
