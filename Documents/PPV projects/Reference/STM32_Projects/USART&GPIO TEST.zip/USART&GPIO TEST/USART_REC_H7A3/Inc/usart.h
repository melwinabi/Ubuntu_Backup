#ifndef USART_H
#define USART_H

#include <stdint.h>

/* -------- USART3 Functions -------- */
void Usart3_Clock_Init(void);
void Usart3_GPIO_Init(void);
void Usart3_Init(uint32_t baud, uint32_t pclk1);

char Usart3_ReadChar(void);
void Usart3_WriteChar(char c);
void Usart3_WriteString(const char *s);
int Usart3_Available(void);
#endif /* USART_H */
