#include <stdint.h>
#include "base.h"
#include "usart.h"

/* Simple software delay */
static void delay(volatile uint32_t count)
{
    while (count--) __asm__("nop");
}

int main(void)
{
    char c;

    /* Init USART3 */
    Usart3_Clock_Init();
    Usart3_GPIO_Init();
    Usart3_Init(115200, 64000000); // Assume PCLK1 = 64 MHz

    Usart3_WriteString("USART3 Echo Test\r\n");

    while (1) {
        if(Usart3_Available())
        {
            c = Usart3_ReadChar();   // wait for RX
            Usart3_WriteChar(c);     // echo back
        }

    }
}
