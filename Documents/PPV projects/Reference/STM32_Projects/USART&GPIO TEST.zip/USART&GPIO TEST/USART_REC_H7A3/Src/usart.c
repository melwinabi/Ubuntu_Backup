#include "base.h"
#include "usart.h"

/* ---------------- USART3 Init ---------------- */
/* On Nucleo-H7A3ZI-Q:
 *   USART3_TX = PD8
 *   USART3_RX = PD9
 */

int Usart3_Available(void)
{
	return (USART3->ISR & (1U << 5)) != 0; // RXNE flag
}

void Usart3_Clock_Init(void)
{
    /* Enable GPIOD and USART3 clocks */
    RCC_AHB4ENR  |= (1U << 3);           // GPIOD enable
    RCC_APB1LENR |= RCC_APB1LENR_USART3EN;
}

void Usart3_GPIO_Init(void)
{
    /* Set PD8 = AF7 (USART3_TX), PD9 = AF7 (USART3_RX) */

    // MODER: alternate function mode (10b)
    GPIOD->MODER &= ~((3U << (8 * 2)) | (3U << (9 * 2)));
    GPIOD->MODER |=  ((2U << (8 * 2)) | (2U << (9 * 2)));

    // AFRH: set AF7
    GPIOD->AFRH &= ~((0xFU << ((8 - 8) * 4)) | (0xFU << ((9 - 8) * 4)));
    GPIOD->AFRH |=  ((7U   << ((8 - 8) * 4)) | (7U   << ((9 - 8) * 4)));

    // Very high speed
    GPIOD->OSPEEDR |= (3U << (8 * 2)) | (3U << (9 * 2));

    // Push-pull
    GPIOD->OTYPER &= ~((1U << 8) | (1U << 9));

    // No pull-up/down
    GPIOD->PUPDR &= ~((3U << (8 * 2)) | (3U << (9 * 2)));
}

void Usart3_Init(uint32_t baud, uint32_t pclk1)
{
    // Configure baud rate
    USART3->BRR = pclk1 / baud;

    // Enable USART, TX, RX
    USART3->CR1 |= (1U << 0); // UE
    USART3->CR1 |= (1U << 2); // RE
    USART3->CR1 |= (1U << 3); // TE
}

char Usart3_ReadChar(void)
{
    while (!(USART3->ISR & (1U << 5))); // Wait RXNE
    return (char)(USART3->RDR & 0xFF);
}

void Usart3_WriteChar(char c)
{
    while (!(USART3->ISR & (1U << 7))); // Wait TXE
    USART3->TDR = c;
}

void Usart3_WriteString(const char *s)
{
    while (*s) {
        Usart3_WriteChar(*s++);
    }
}
